/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.icetask3;

/**
 *
 * @author kuhlulankuna
 */
public class Car {
    public void speed(){
        System.out.println("This car can speed up to 266km/h");
        
        String name = "Mustang";
        System.out.println("Car name: "+name);
    }
}
