/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.icetask3;

/**
 *
 * @author kuhlulankuna
 */
public class ICETASK3 {

    public static void main(String[] args) {
   
        Person person = new Person();
        person.name = "Hello Kuhlula";
        person.surname = "Nkuna";
        System.out.println("Hello Kuhlula!");
    
        Car newCar = new Car();
        newCar.speed();
    }//Class main
}//ICE TASK3 
class Person {// This is a class i created myself
    public String name; //We are declaring the variable name
    public String surname;
            
    public void Speak() {
        name = "Kuhlula";
        System.out.println(name+" can speak" );
    }
    
}
